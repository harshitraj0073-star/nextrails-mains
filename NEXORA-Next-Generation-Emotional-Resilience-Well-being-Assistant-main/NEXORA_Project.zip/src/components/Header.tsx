import React from 'react';
import { useStore } from '../hooks/useStore';
import { useDarkMode } from '../hooks/useDarkMode';
import { LogOut, Globe, Shield, User, Sun, Moon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export const Header: React.FC = () => {
  const { state, setLanguage, setRole } = useStore();
  const { isDark, toggle } = useDarkMode();
  const navigate = useNavigate();

  const handleLogout = () => {
    setRole(null);
    navigate('/');
  };

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-30 h-16 flex items-center justify-between px-4 sm:px-6">
      <div className="flex items-center gap-2">
        <Shield className="w-8 h-8 text-primary" />
        <div>
          <h1 className="font-bold text-slate-800 hidden sm:block leading-tight">NEXORA</h1>
          <p className="text-xs text-slate-500 hidden sm:block">Support System</p>
        </div>
      </div>

      <div className="flex items-center gap-4">
        {state.role === 'victim' && (
          <div className="bg-green-50 text-green-700 px-3 py-1 rounded-full text-sm font-medium flex items-center gap-1">
            <Shield className="w-4 h-4" />
            <span className="hidden sm:inline">Secure Session</span>
          </div>
        )}

        {/* Language Selector */}
        <div className="relative group">
          <button className="flex items-center gap-1 text-slate-600 hover:text-slate-900 transition-colors">
            <Globe className="w-5 h-5" />
            <span className="text-sm font-medium uppercase">{state.language}</span>
          </button>
          <div className="absolute right-0 mt-2 w-32 bg-white rounded-md shadow-lg border border-slate-200 hidden group-hover:block z-50">
            <div className="py-1">
              <button onClick={() => setLanguage('en')} className="block w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-100">English</button>
              <button onClick={() => setLanguage('hi')} className="block w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-100">हिंदी</button>
              <button onClick={() => setLanguage('bn')} className="block w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-100">বাংলা</button>
            </div>
          </div>
        </div>

        {/* Dark / Light Mode Toggle */}
        <button
          onClick={toggle}
          title={isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
          className="p-2 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-all duration-200"
          aria-label="Toggle dark mode"
        >
          {isDark
            ? <Sun className="w-5 h-5 text-amber-400" />
            : <Moon className="w-5 h-5" />
          }
        </button>
        
        {state.role && (
          <div className="flex items-center gap-3 border-l border-slate-200 pl-4">
            <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-600">
              <User className="w-5 h-5" />
            </div>
            <button 
              onClick={handleLogout}
              className="text-slate-500 hover:text-red-600 transition-colors p-2 rounded-md hover:bg-red-50"
              title="Logout"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        )}
      </div>
    </header>
  );
};
